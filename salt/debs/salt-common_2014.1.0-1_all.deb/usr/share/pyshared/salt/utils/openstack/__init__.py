# -*- coding: utf-8 -*-
'''
Init Openstack apis
'''
